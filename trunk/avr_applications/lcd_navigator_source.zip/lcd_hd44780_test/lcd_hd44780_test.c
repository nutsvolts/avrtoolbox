/*
 *  BSD License
 *  -----------
 *
 *  Copyright (c) 2011, Joe Pardue, All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  - Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer. 
 *   
 *  - Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution. 
 *   
 *  - Neither the name of Joe Pardue nor the names of 
 *    its contributors may be used to endorse or promote products derived from 
 *    this software without specific prior written permission. 
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */
 
 // Some of this code may have elements taken from other code without attribution.
 // If this is the case it was due to oversight while debugging and I apologize.
 // If anyone has any reason to believe that any of this code violates other licenses
 // please contact me with details so that I may correct the situation. 

// This software was liberally influenced by:
// [TUT][C] LCD Tutorial 1001 by Peter Dannegger
// http://www.avrfreaks.net/index.php?name=PNphpBB2&file=viewtopic&p=828978
// And by the LiquidCrystal library for the Arduino
// Many changes were made to fit it into the avrtoolbox format.

// lcd_hd44780_test.c 
// Oct 22, 2011


#include "lcd.h"

const char line1[] PROGMEM =  "Line 1";
#ifdef LCD_LINE2
const char line2[] PROGMEM =  "Line 2";
#ifdef LCD_LINE3
const char line3[] PROGMEM =  "Line 3";
#ifdef LCD_LINE4
const char line4[] PROGMEM =  "Line 4";
#endif  
#endif  
#endif

const char pgm_str1[] PROGMEM =  "!Smiley!";
const char pgm_str2[] PROGMEM =  "!Micros!";


int main( void )
{
	lcd_init();

	lcd_puts("Hello!");
	delay(1000);
	lcd_clear();
	lcd_puts("REV005");
	delay(1000);

  lcd_set_cursor( 0, 0 );
  lcd_puts_p(line1 );
#ifdef LCD_LINE2
  lcd_set_cursor( 0, 1 );
  lcd_puts_p(line2 );
#ifdef LCD_LINE3
  lcd_set_cursor( 0, 2 );
  lcd_puts_p(line3);
#ifdef LCD_LINE4
  lcd_set_cursor( 0, 3 );
  lcd_puts_p(line4);
#endif  
#endif  
#endif 
/**/

  for(;;){

/*   	lcd_set_cursor( 0, 0 );
	lcd_puts("Hello!5");
	delay(500);
	lcd_clear();
	delay(500);

	for(int i = 0x30 ; i < 0x038; i++)
	{
		lcd_putc(i);
	}
	delay(500);
*/

	/*
	// Test lcd_set_cursor, lcd_putc, and lcd_clear 
	// writes 0 to 7 in opposite directions in lines 1 and 2
	for(int i = 0x30 ; i < 0x038; i++)
	{
		lcd_set_cursor(7-(i-0x30),0);
		lcd_putc(i);
		lcd_set_cursor(i-0x30,1);
		lcd_putc(i);

		delay(500);	
	}
	lcd_clear();
	delay(500);
	*/

	
	/*// Test lcd_home
	// writes 0 to 7 in opposite directions in lines 1 and 2
	for(int i = 0x30 ; i < 0x038; i++)
	{
		lcd_home();
		lcd_putc(i);

		delay(500);	
	}
	lcd_clear();
	delay(500);
	*/

/*	// Test lcd_puts
	lcd_home();
	lcd_puts("*Smiley*");
	lcd_set_cursor(0,1);
	lcd_puts("*Micros*");
	delay(500);	
	lcd_clear();
	delay(500);
*/

/*	// Test lcd_puts_p and lcd_blank
	lcd_home();
	lcd_puts_p(pgm_str1);
	lcd_set_cursor(0,1);
	lcd_puts_p(pgm_str2);
	delay(500);	
	//lcd_clear();
	lcd_blank(4);
	delay(500);
	lcd_blank(4);
	delay(500);
	lcd_blank(4);
	delay(500);
	lcd_blank(4);
	delay(500);
*/	

/*	// Test lcd_cursor_on and lcd_cursor_off 
	// and lcd_blink_on and lcd_blink_off
	// and lcd_display_on and lcd_display_off
	lcd_putc('A');
	lcd_cursor_on();
	delay(500);
	lcd_putc('B');
	lcd_cursor_off();
	delay(500);
	lcd_blink_on();
	delay(500);
	lcd_blink_off();
	delay(500);
	lcd_display_off();
	delay(500);
	lcd_display_on();
	delay(500);
*/

	lcd_clear();
	// Reveal the answer
	char answer[] = "LOVE YOU";
	lcd_puts("????????");
	delay(1000);
	lcd_home();
	for(int i = 0; i < 8; i++)
	{
		lcd_putc((uint8_t) answer[i]);
		delay(1000); 
	}

	



  }
}


void delay(uint16_t ms)
{
	for(int i = 0 ; i < ms ; i++)
	{
		_delay_ms(1);
	}
}



