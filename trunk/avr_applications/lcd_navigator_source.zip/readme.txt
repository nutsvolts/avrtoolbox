Joe Pardue - 3/7/12
This zip file contains the test source code for the LCD Navigator project. These files are a snapshot of the code with all the sources placed in one directory for user convenience. THIS CODE WORKS BUT WILL NOT BE UPDATED. The up to date code is in the avrtoolbox repository and requires that the user know how to access this code and store it in a directory structure on their PC that exactly mimics the repository. All files must be located under the /avrtoolbox directory as they are in the repository. There are blog entries that explain all this.

The current lcd navigator source code is available at:
http://code.google.com/p/avrtoolbox/libavr/source/driver/external_hardware/lcd_hd44780
http://code.google.com/p/avrtoolbox/libavr/testers/lcd_hd44780
http://code.google.com/p/avrtoolbox/libavr/source/driver\external_hardware/nav_button
http://code.google.com/p/avrtoolbox/libavr/testers/nav_buttons
http://code.google.com/p/avrtoolbox/libavr/testers/nav_buttons/atmega328_label.doc